import java.util.*;

public class Calender{
 public static void main(String args[]){
  int day,month,year;
  Scanner sc=new Scanner(System.in);
  day=sc.nextInt();
  month=sc.nextInt();
  year=sc.nextInt();
  System.out.println(getDay());
}}