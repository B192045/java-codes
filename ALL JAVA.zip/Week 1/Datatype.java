import java.util.*;

public class Datatype{
public static void main(String args[]){
 Scanner sc=new Scanner(System.in);
int i;
 int t=sc.nextInt();
 for(i=0;i<t;i++){
 try{
 long x=sc.nextLong();
 if(x>=Byte.MIN_VALUE&&x<=Byte.MAX_VALUE){
 System.out.println(x+"can be fitted in: ");
 System.out.println("*byte");
 System.out.println("*short");
System.out.println("*int");
System.out.println("*long");}
if(x>=Short.MIN_VALUE&&x<=Short.MAX_VALUE){
 System.out.println(x+"can be fitted in: ");
 System.out.println("*short");
System.out.println("*int");
System.out.println("*long");}
if(x>=Integer.MIN_VALUE&&x<=Integer.MAX_VALUE){
 System.out.println(x+"can be fitted in: ");
System.out.println("*int");
System.out.println("*long");}
if(x>=Long.MIN_VALUE&&x<=Long.MAX_VALUE){
 System.out.println(x+"can be fitted in: ");
System.out.println("*long");}
else{
System.out.println(x+" can't be fitted anywhere");}

}}}}


