import java.util.*;

class Prime{
 public static void main(String args[]){
  int n;
  Scanner sc=new Scanner(System.in);
  n=sc.nextInt();
  int c=0,i;
  for(i=1;i<=n;i++){
   if(n%i==0)
   c++;
}

  if(c==2)
 System.out.println("Prime");
else
System.out.println("Not");
}
}