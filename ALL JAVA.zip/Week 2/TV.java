import java.util.*;

class TV{
 int channel;
 int volume;
 boolean on;
int newVolume;
int newChannel;

public TV(){
 this.channel=1;
 this.volume=1;
 this.on=false;}

void turnOn(){
if(!on){
 on=true;
 System.out.println("TV is on");
}}

void turnOff(){
if(on){
 on=false;
 System.out.println("TV is off");
}}

void setChannel(int newChannel){
 if(on&&newChannel>=1&&newChannel <=40){
  channel=newChannel;
  System.out.println("TV is set to "+channel);}
 else
 System.out.println("unfit");}

void setVolume(int newVolume){
 if(on&&volume>=1&&volume<=7){
  volume=newVolume;
  System.out.println("Volume is set to "+volume);}
 else
 System.out.println("unfit");}

void channelUp(){
if(on){
 channel++;
System.out.println(channel);}}

void channelDown(){
if(!on){
 channel--;
System.out.println(channel);}}

void volumeUp(){
 volume++;
System.out.println(volume);}

void volumeDown(){
 volume--;
System.out.println(volume);}

public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("SELECT NUMBER\n2-->SWITCH ON TV\n3-->TURN OFF\n4-->SET CHANNEL NUMBER\n5-->SET VOLUME\n6-->CHANNEL UP\n7-->CHANNEL DOWN\n8-->VOLUME UP\n9-->VOLUME DOWN");
int a=sc.nextInt();
TV t1=new TV();
switch(a){
 case 2:
 t1.turnOn();
 break;
 case 3:
 t1.turnOff();
 break;
 case 4:
 t1.setChannel(5);
 break;
 case 5:
 t1.setVolume(6);
 break;
 case 6:
 t1.channelUp();
 break;
 case 7:
 t1.channelDown();
 break;
 case 8:
 t1.volumeUp();
 break;
 case 9:
 t1.volumeDown();
 break;}}}
 
 

 