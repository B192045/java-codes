import java.util.*;

public class Circle{
 double radius;

Circle(double radius){
 this.radius=radius;
 }

void getArea(){
 double area=3.14*radius*radius;
 System.out.println(area);}

void getPerimeter(){
  double perimeter=3.14*2*radius;
System.out.println(perimeter);}

public static void main(String args[]){
 Circle c1=new Circle(5);
 Circle c2=new Circle(10);
Circle c3=new Circle(15);
c1.getArea();
c2.getArea();
c3.getArea();
c1.getPerimeter();
c2.getPerimeter();
c3.getPerimeter();}}





