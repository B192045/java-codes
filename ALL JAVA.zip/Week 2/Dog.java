import java.util.*;

public class Dog{
 String name;
 String breed;
 String color;
 double height;
 String type;
 
public Dog(String name,String breed,String color,double height,String type){
 this.name=name;
 this.breed=breed;
 this.color=color;
 this.height=height;
 this.type=type;}

void getName(){
 System.out.println(name);}

void getBreed(){
 System.out.println(breed);}

void getColor(){
 System.out.println(color);}

void getHeight(){
 System.out.println(height);}

void getType(){
 System.out.println(type);}

public static void main(String args[]){
  Dog object1=new Dog("snoopy","pomerian","white",1,"gaurd");
  Dog object2=new Dog("rocky","lab","brown",3,"sniffer");
  Dog object3=new Dog("snowy","sheperd","black",4,"sheperd");
  object1.getName();
  object1.getBreed();
  object1.getColor();
  object1.getHeight();
  object1.getType();}}
  
