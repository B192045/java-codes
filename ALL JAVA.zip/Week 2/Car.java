import java.util.*;

public class Car{
 String company;
 double mileage;
 double speed;
 String color;
 
public Car(String company,double mileage,double speed,String color){
 this.company=company;
 this.mileage=mileage;
 this.speed=speed;
 this.color=color;}

void getMileage(){
 return this.mileage;
  }
 
void getSpeed(){
return this.getSpeed;
}


public static void main(String args[]){
 Car object1=new Car("Ford",65,60,"red");
 Car object2=new Car("Toyota",67,70,"blue");
 Car object3=new Car("Alto",72,80,"green");
 Car suggested=suggested(object1,object2,object3);
 
 System.out.println("Suggested car details:");
 System.out.println("Mileage: "+suggested.getMileage());
 System.out.println("Speed: "+suggested.getSpeed());

 
 
 
 
 
 