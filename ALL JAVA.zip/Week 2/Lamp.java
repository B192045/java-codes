import java.util.*;

class Lamp{
 boolean isOn;
 String lamptype;
 
Lamp(boolean isOn,String lamptype){
 this.isOn=isOn;
 this.lamptype=lamptype;}

void turnOn(){
 if(isOn==true)
 System.out.println("light is on");}

void turnOff(){
 if(isOn==false)
 System.out.println("light is off");}

public static void main(String args[]){
 Lamp led=new Lamp(true,"led");
 Lamp hal=new Lamp(false,"hal");
 led.turnOn();
 hal.turnOff();}}
 
 

