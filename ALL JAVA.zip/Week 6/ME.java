package dept;

interface batch{
void display_subjects();}

public class ME implements batch{
public void display_subjects(){
System.out.println("EC,DECO,MS");}}
