import java.util.*;

class Account{
    double balance;
    Account(double balance){
        this.balance=balance;
    }
    void credit(int amount){
       balance=balance+amount;
       System.out.println("Amount credited,New balance is "+balance);
    }
    int debit(int amount){
        if(balance>=amount){
       balance=balance-amount;
       System.out.println("Amount debited,New balance is "+balance);}
        System.out.println("Insufficient funds");
    }
    void getbalance(){
        System.out.println("current balance "+balance);}

    public void exit(){
        System.out.println("Exiting transaction");
    }
}

public class Week4{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        
    }
}