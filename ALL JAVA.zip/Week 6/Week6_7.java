//error in switch it is only switching on tv not moving further

import java.util.*;
import Remote.TV;

public class Week6_7{
 public static void main(String args[]){
 TV t1=new TV();
 Scanner sc=new Scanner(System.in);
int s=sc.nextInt();
 System.out.println("we have 6 channels select the numbers");
 while(s!=7){
 System.out.println("1.SWITCH ON 2.STAR SPORTS 3.NGC 4.DISCOVERY 5.STARMOVIES 6.SWITCH OFF 7.EXIT");
 int n=sc.nextInt();
 switch(n){
 case 1:t1.switch_on();
 break;
 case 2:t1.star_sports();
 break;
 case 3:t1.ngc();
 break;
 case 4:t1.discovery();
 break;
 case 5:t1.starmovies();
 break;
 case 6:t1.switch_off();
 break;
 case 7:System.out.println("Exiting");
 System.exit(0);
 }}}}
 
 
 