import java.util.*;

class RBI{
    int amount;
    int balance;
     public int credit(int amount){
         balance=balance+amount;
         return balance;
    }
    public int debit(int amount){
         balance=balance-amount;
         return balance;
    }
   public void displayAmount(){
    System.out.println("Remaining balance is: "+balance);
   }
}

class SBI extends RBI{
    void Personal_loan_eligibility(int age,String jobtype,boolean marriage){
        if(super.balance>=100){
        if(age>20&&jobtype.equalsIgnoreCase("GOVT")&&marriage==true)
        System.out.println("Eligible for personal loan");
    }
else
System.out.println("Not Eligible for personal loan");}
}

public class Week5_5{
    public static void main(String args[]){
        RBI r=new RBI();
        SBI s=new SBI();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter amount to credit: ");
        int n=sc.nextInt();
         System.out.println("Enter amount to debit: ");
        int o=sc.nextInt();
        System.out.println("Credited amount is: "+r.credit(n));
        System.out.println("After debited amount: "+r.debit(o));
        r.displayAmount();
        s. Personal_loan_eligibility(35,"govt",true);
    }
}