import java.util.*;
import sounds.Podcast;

public class Week6_4{
 public static void main(String args[]){
 Podcast.Podcasts a=new Podcast.Podcasts();
 Podcast.inter b=new Podcast.inter();
 Scanner sc=new Scanner(System.in);
 System.out.println("enter num of songs u want: ");
 int c=sc.nextInt();
 while(c>=0){
 System.out.println("choose song 1.melody 2.rapo 3.devotional 4.Dolby");
 int n=sc.nextInt();
 switch(n){
 case 1:a.playPodcast("melody");
        break;
 case 2:a.playPodcast("rapo");
        break;
 case 3:a.playPodcast("devotional");
        break;
 case 4:b.playDolby();
        break;}
        c--;}}}