package admission;

public class Class9{
 int maths;
 int physics;
 int chemistry;
 int english;
/* Class9(int maths,int physics,int chemistry,int english){
 this.maths=maths;
 this.physics=physics;
 this.chemistry=chemistry;
 this.english=english;}*/
 
public int maths_marks(int maths){
 if(maths>=90)
 return 1;
 return 0;}

public int physics_marks(int physics){
 if(physics>=95)
 return 1;
 return 0;}

public int chemistry_marks(int chemistry){
 if(chemistry>=70)
 return 1;
 return 0;}

public int english_marks(int english){
 if(english>=80)
 return 1;
 return 0;}

public int percent_age(int percentage){
 if(percentage>=80)
 return 1;
 return 0;}
}








 