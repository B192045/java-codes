package shape;

public abstract class All{
public static class Square{
int s;
public Square(int s){
this.s=s;}

 public int getArea(){
 return s*s;}
 public int getPerimeter(){
 return 4*s;}}
 
 public static class Circle{
int s;
public Circle(int s){
this.s=s;}

 public double getArea(){
 return 3.14*s*s;}
 public double getPerimeter(){
 return 2*3.14*s;}}
 
public static class Triangle{
int s;
int b;
int a;

public Triangle(int s,int b,int a){
this.s=s;
this.b=b;
this.a=a;}

 public double getArea(){
 return 0.5*b*s;}
 public int getPerimeter(){
 return a+b+s;}}}
