/*1. Implement a Calculator application : Include all calculator operations as
abstract methods in a interface and include it in a Package “calculator” and
implement all operations in a class and import the package to design calculator.*/

package calculator;
 interface calculate{
 double addition(double x,double y);
 double multiplication(double x,double y);
double subtraction(double x,double y);
 double division(double x,double y);}
 
 public class Operations implements calculate{
 public double addition(double x,double y){
 return x+y;}
 
  public double multiplication(double x,double y){
 return x*y;}
 
 public double subtraction(double x,double y){
 return x-y;}
 
  public  double division(double x,double y){
 return x/y;}}
 
