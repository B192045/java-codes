package dept;

interface batch{
void display_subjects();}

public class CE implements batch{
public void display_subjects(){
System.out.println("AEC,DEC,DBMS");}}
