import java.util.*;

import dept.CSE;
import dept.ECE;
import dept.ME;
import dept.CE;

public class Week6_2{
  public static void main(String args[]){
   CSE c1=new CSE();
   c1.display_subjects();
   ECE e1=new ECE();
   e1.display_subjects();
   ME m1=new ME();
   m1.display_subjects();}}
