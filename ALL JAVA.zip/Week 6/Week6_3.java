import java.util.*;
import shape.All;

public class Week6_3{
public static void main(String args[]){
   All.Square s=new All.Square(3);
   All.Circle c=new All.Circle(4);
   All.Triangle t=new All.Triangle(1,2,3);
   System.out.println(s.getArea());
   System.out.println(s.getPerimeter());
   System.out.println(c.getArea());
   System.out.println(c.getPerimeter());
    System.out.println(t.getArea());
   System.out.println(t.getPerimeter());}}
