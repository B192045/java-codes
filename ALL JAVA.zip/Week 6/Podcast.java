package sounds;
 
interface dolby{
void playDolby();}

public abstract class Podcast{
public static class Podcasts{
 String song;
  public void playPodcast(String song){
 if(song.equals("melody"))
 System.out.println("play melodious song");
 else if(song.equals("rapo"))
 System.out.println("play rapo song");
 else if(song.equals("devotional"))
 System.out.println("play devotional song");}}

public static class inter{
 public void playDolby(){
 System.out.println("play dolby song");}}}
 
 