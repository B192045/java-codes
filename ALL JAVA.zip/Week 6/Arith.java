package complex;

public class Arith{
 public int rp,ip;
 public int a1,a2;
 public int b1,b2;
 /*Arith(int rp,int ip){
 this.rp=rp;
 this.ip=ip;}*/

public void Arith(){
 rp=0;
 ip=0;}

 public int add(int a1,int a2){
 rp=a1+a2;
 return rp;}

 public int ad(int b1,int b2){
 ip=b1+b2;
 return ip;}

 public int sub(int a1,int a2){
 rp=a1-a2;
 return rp;}

 public int sd(int b1,int b2){
 ip=b1-b2;
 return ip;}}


 


 
 