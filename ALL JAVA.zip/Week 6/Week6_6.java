import java.util.*;

import Mseva.Symptoms;

// but problem is it is printing not found automatically

public class Week6_6{
 public static void main(String args[]){
 Scanner sc=new Scanner(System.in);
 Symptoms s1=new Symptoms();
  System.out.println("WELCOME TO MSEVA");
 System.out.println("enter num of symptoms: ");
 int n=sc.nextInt();
 System.out.println("enter symptoms: ");
 while(n>0){
 String a=sc.nextLine();
 s1.disease(a);
 n--;}
}}