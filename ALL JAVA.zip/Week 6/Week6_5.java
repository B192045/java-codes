import java.util.*;

import complex.Arith;

public class Week6_5{
 public static void main(String args[]){
 Arith a1=new Arith();
 a1.add(5,6);
 a1.ad(1,2);
 System.out.println(a1.rp+"+"+a1.ip+"i");
}}