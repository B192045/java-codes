import java.util.*;
import calculator.Operations;

class Week6_1{
 public static void main(String args[]){
 Operations c1=new Operations();
 System.out.println("Enter two numbers: ");
 Scanner sc=new Scanner(System.in);
 double x=sc.nextDouble();
 double y=sc.nextDouble();
 System.out.println("enter operations to perform 1.addition 2.multiplication 3.subtraction 4.division");
 int n=sc.nextInt();
 switch(n){
 case 1:System.out.println(c1.addition(x,y));
 break;
 case 2:System.out.println(c1.multiplication(x,y));
 case 3:System.out.println(c1.subtraction(x,y));
 case 4:System.out.println(c1.division(x,y));}}}
