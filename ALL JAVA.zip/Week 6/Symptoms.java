package Mseva;

public class Symptoms{
 String symptom;

 public void disease(String symptom){
 if(symptom.equalsIgnoreCase("muscle ache")||symptom.equalsIgnoreCase("fever"))
 System.out.println("AP");
 if(symptom.equalsIgnoreCase("fever")||symptom.equalsIgnoreCase("fatigue"))
 System.out.println("A");
 if(symptom.equalsIgnoreCase("skin allergy")||symptom.equalsIgnoreCase("low bp"))
 System.out.println("BC");
 if(symptom.equalsIgnoreCase("fever")||symptom.equalsIgnoreCase("fatigue"))
 System.out.println("PC");
 else
 System.out.println("Symptom not found");}}
 
 