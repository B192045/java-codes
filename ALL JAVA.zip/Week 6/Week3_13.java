import java.util.*;

public class Week3_13{
     public static void main(String args[]){
        int success=0;
        int n=0;
       Scanner sc=new Scanner(System.in);
       while(n!=11){
       System.out.println("Roll two dices and tell the output: ");
       int a=sc.nextInt();
       int b=sc.nextInt();
       if(a==b)
       success++;
       n++;}
       System.out.println("Num of successfull attempts are "+success);
    }
}