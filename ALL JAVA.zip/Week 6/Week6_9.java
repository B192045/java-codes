import java.util.*;
import admission.Class9;

class Week6_9{
 public static void main(String args[]){
 Class9 c1=new Class9();
 Scanner sc=new Scanner(System.in);
 System.out.println("enter num of students: ");
 int n=sc.nextInt();
 while(n>0){
 System.out.println("Enter maths marks: ");
 int maths=sc.nextInt();
 System.out.println("Enter physics marks: ");
 int physics=sc.nextInt();
 System.out.println("Enter chemistry marks: ");
 int chemistry=sc.nextInt();
 System.out.println("Enter english marks: ");
 int english=sc.nextInt();
 int percentage=((maths+physics+chemistry+english)/400)*100;
 if(c1.maths_marks(maths)==1&&c1.physics_marks(physics)==1&&c1.chemistry_marks  (chemistry)==1&&c1.english_marks(english)==1&&c1.percent_age(percentage)==1)
 System.out.println("Eligible");
 else
 System.out.println("Not Eligible");
 n--;}}}