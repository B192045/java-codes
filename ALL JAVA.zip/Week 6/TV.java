package Remote;

public class TV{
 public void switch_on(){
 System.out.println("Welcome to tata sky");}
 public void switch_off(){
 System.out.println("TV is off");}
 public void star_sports(){
 System.out.println("Welcome to tata sports");}
 public void ngc(){
 System.out.println("Welcome to ngc");}
 public void discovery(){
 System.out.println("Welcome to discovery");}
 public void starmovies(){
 System.out.println("Welcome to star movies");}}
 
 
 