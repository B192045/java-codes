import java.util.*;

class AgentException extends Exception{
 public AgentException(String str){
 super(str);}}

class AC{
 int seats;
  int capacity=70;
 AC(int seats){
 this.seats=seats;}
 void reserved(){
 System.out.println(seats);
 capacity=capacity-seats;
 System.out.println("Remaining seats are "+capacity);}}

class Sleeper{
 int seat;
 int capacit=70;
 Sleeper(int seat){
 this.seat=seat;}
 
 void reserve(){
 System.out.println(seat+" are booked");
 capacit=capacit-seat;
 System.out.println("Remaining seats are "+capacit);}}
 
class Week7_5{
 public static void main(String args[]){
 Scanner sc=new Scanner(System.in);
 try{
 System.out.println("Enter required berths for ac: ");
 int n=sc.nextInt();
 if(n>6){
 throw new AgentException("you may be agent");}
 else{
 System.out.println("Enter required berths for sleeper: ");}
 int o=sc.nextInt();
 if(n>0&&o>0)
 throw new AgentException("you may be agent");
 AC a=new AC(n);
 Sleeper s=new Sleeper(o);
 a.reserved();
 s.reserve();}
 catch(AgentException e){
 System.out.println("Exception: "+e.getMessage());}
 }}