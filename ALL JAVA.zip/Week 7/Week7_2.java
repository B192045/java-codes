import java.util.*;
import bank.Bankmanagement;

public class Week7_2{
 public static void main(String args[]){
 Scanner sc=new Scanner(System.in);
 String username=sc.nextLine();
 String password=sc.nextLine();
 Bankmanagement b=new Bankmanagement("aish","aish20",2000);
 int n=sc.nextInt();
 System.out.println("Select operation:1.Debit  2.Credit   3.Display");
try{
 b.credentialcheck(username,password);}
catch(Exception e){
System.out.println("Exception: "+e.getMessage());}
 b.credit(1000);
try{
 b.debit(300);}
catch(Exception e){
System.out.println("Exception: "+e.getMessage());}
 b.displaybalance();
 b.exit();}
 }