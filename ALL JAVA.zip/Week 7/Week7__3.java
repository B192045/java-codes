import java.util.*;
import audit.Taxdepartment;

public class Week7__3{
      public static void main(String args[]){
      Taxdepartment t1=new Taxdepartment();
       t1.taxpaid();
       t1.homeexpenditure();
        t1.healthexpenditure();
        t1.vehicleexpenditure();
        t1.personalfamilyexpenditure();
        t1.miscellaneousexpenditure();
         t1.taxchecker();}}
