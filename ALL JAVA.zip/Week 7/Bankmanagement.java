package bank;

interface functionalities{
 void credentialcheck(String username,String password);
 void credit(int amount);
 void debit(int amount);
 void displaybalance();
 void exit();}

class mismatchexception extends Exception{
public mismatchexception(String str){
super(str);}}

class insufficientexception extends Exception{
public insufficientexception(String str){
super(str);}}


public class Bankmanagement{
 String username;
 String password;
 int balance;
 public Bankmanagement(String username,String password,int balance){
 this.username=username;
 this.password=password;
 this.balance=balance;}

  public void credentialcheck(String username,String password) throws mismatchexception{
  if(!this.username.equals(username) || !this.password.equals(password))
  throw new mismatchexception("Invalid login credentials");}

 public void credit(int amount){
 balance=balance+amount;
 System.out.println("After crediting balance is: "+balance);}

 public void debit(int amount) throws insufficientexception{
 if(amount>balance)
 throw new insufficientexception("Insufficient balance");
 else{
 balance=balance-amount;
 System.out.println("After crediting balance is: "+balance);}}

 public void displaybalance(){
 System.out.println(balance);}
 
 public void exit(){
 System.out.println("Process exited,Thank you");}}

 

 


