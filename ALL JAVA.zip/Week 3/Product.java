import java.util.*;

public class Product{
 public static void main(String args[]){
 double retail=0;
 double total=0;
   Scanner sc=new Scanner(System.in);
   while(true){
   System.out.println("Enter product_id(exit to stop): ");
   String s=sc.next();
   if(s=="exit")
   break;
  System.out.println("Enter quantity(0 to stop): ");
   int qty=sc.nextInt();
  if(qty==0)
  break;
    double cost=0;
     switch(s){
       case "product1":
       cost=99.9;
       break;
       case "product2":
       cost=20.2;
       break;
       case "product3":
       cost=6.87;
       break;
       case "product4":
       cost=45.5;
       break;
       case "product5":
       cost=40.49;
       break;}
   retail=cost*qty;
   total=total+retail;}
System.out.println(total);}}