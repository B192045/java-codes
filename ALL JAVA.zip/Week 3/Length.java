import java.util.*;

public class Length{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   String A=sc.nextLine();
   System.out.println(A.length());
   }}