import java.util.*;

public class Equals{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   String A=sc.nextLine();
   String B=sc.nextLine();
   if(A.equals(B))
   System.out.println("EQUAL");
   else if(!A.equals(B))
   System.out.println("Not equal");
   if(A.equalsIgnoreCase(B))
   System.out.println("EQUAL after ignoring cases");
   else if(!A.equalsIgnoreCase(B))
   System.out.println("Not EQUAL after ignoring cases");
  
  
   
 
   }}