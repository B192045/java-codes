import java.util.*;

public class Reverse{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
  int i;
   String A=sc.nextLine();
   for(i=A.length()-1;i>=0;i--)
   System.out.print(A.charAt(i));
}}