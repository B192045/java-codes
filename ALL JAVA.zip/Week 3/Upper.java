import java.util.*;

public class Upper{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   String A=sc.nextLine();
   String B=A.toUpperCase();
   String C=B.toLowerCase();
   System.out.println(B+" "+C);
   
  
  
   
 
   }}