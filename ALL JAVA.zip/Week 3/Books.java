import java.util.*;

class EBook {
    String Book_name;
    String Book_author;
    int Book_count;

    EBook(String Book_name, String Book_author, int Book_count) {
        this.Book_name = Book_name;
        this.Book_author = Book_author;
        this.Book_count = Book_count;
    }

    public String getBook() {
        return Book_name;
    }

    public String getAuthor() {
        return Book_author;
    }

    public int getCount() {
        return Book_count;
    }

    public void decrease() {
        if (Book_count > 0)
            Book_count--;
    }
}

class Customer {
    int Customer_id;
    String Customer_name;
    String Customer_address;

    public Customer(int Customer_id, String Customer_name, String Customer_address) {
        this.Customer_name = Customer_name;
        this.Customer_id = Customer_id;
        this.Customer_address = Customer_address;
    }

    public String getName() {
        return Customer_name;
    }

    public String getAddress() {
        return Customer_address;
    }

    public int getId() {
        return Customer_id;
    }

    public void buyBook(EBook book) {
        if (book.getCount() > 0) {
            book.decrease();
            System.out.println(Customer_name + " bought " + book.getBook());
            System.out.println("Remaining are " + book.getCount());
        } else {
            System.out.println("Sorry, " + book.getBook() + " is out of stock.");
        }
    }
}

public class Books {
    public static void main(String args[]) {
        EBook book1 = new EBook("ONE NIGHT", "AISH", 5);
        EBook book2 = new EBook("ONE DAY", "AMU", 5);

        Customer c1 = new Customer(1, "Customer1", "Address1");
        Customer c2 = new Customer(2, "Customer2", "Address2");

        c1.buyBook(book1);
        c1.buyBook(book1);
        c2.buyBook(book2);
    }
}
