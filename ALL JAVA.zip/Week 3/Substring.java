import java.util.*;

public class Substring{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   String A=sc.nextLine();
   String B=sc.nextLine();
   if(A.contains(B))
   System.out.println("substring");
   else
   System.out.println("not a substring");
 
   }}