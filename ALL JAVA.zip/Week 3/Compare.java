import java.util.*;

public class Compare{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   String A=sc.nextLine();
   String B=sc.nextLine();
   if(A.compareTo(B)==0)
   System.out.println("EQUAL");
   else if(A.compareTo(B)>0)
   System.out.println("A is greater than B");
   else
   System.out.println("B is greater than A");
   }}