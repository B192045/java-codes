import java.util.*;

public class Chatgpt {
    public static void main(String args[]) {
        double totalRetailValue = 0;
        double retailValue;
        double productTotal; // Use double for product_total
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter product id (or 'exit' to quit): ");
        while (true) {
            String id = sc.next();

            if (id.equals("exit")) {
                break;
            }

            System.out.println("Enter quantity of " + id + ": ");
            double qty = sc.nextDouble(); // Use double for qty

            // Use a switch statement to set retail_value based on the product id
            switch (id) {
                case "product1":
                    retailValue = 99.9;
                    break;
                case "product2":
                    retailValue = 20.20;
                    break;
                case "product3":
                    retailValue = 6.87;
                    break;
                case "product4":
                    retailValue = 45.5;
                    break;
                case "product5":
                    retailValue = 40.49;
                    break;
                default:
                    retailValue = 0; // Set to 0 if the product id is not recognized
                    break;
            }

            productTotal = retailValue * qty;
            totalRetailValue += productTotal;
        }

        System.out.println("Total retail value: " + totalRetailValue);
    }
}
