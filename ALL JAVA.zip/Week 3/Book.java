import java.util.*;

class Ebook{
 String Book_name;
 String Book_author;
 int Book_count;
  
Ebook(String Book_name, String Book_author, int Book_count){
   this.Book_name=Book_name;
   this.Book_author=Book_author;
   this.Book_count=Book_count;}

public String get_book(){
 return Book_name;}

public String get_author(){
 return Book_author;}

public int get_count(){
 return Book_count;}

public void decrease(){
  if(Book_count>0)
  Book_count--;}
}

 class Customer{
  int Customer_id;
  String Customer_name;
  String Customer_address;

public Customer(int Customer_id,String Customer_name,String Customer_address){
   this.Customer_name=Customer_name;
   this.Customer_id=Customer_id;
   this.Customer_address= Customer_address;}

public String get_name(){
  return Customer_name;}

public String get_address(){
  return Customer_address;}

public int get_id(){
  return Customer_id;}

public void buy_book(Ebook book){
 if(book.get_count()>0)
 book.decrease();
 System.out.println(Customer_name+ " "+"brought "+book.get_book());
 System.out.println("Remaining are "+book.get_count());
}
}

public class Book{
  public static void main(String args[]){
   Ebook book1=new Ebook("ONE NIGHT","AISH",5);
   Ebook book2=new Ebook("ONE DAY","AMU",5);
   Customer c1=new Customer(1,"cust1","nml");
  Customer c2=new Customer(2,"cust2","zb");
 c1.buy_book(book1);
 c1.buy_book(book2);}}
 
  




 