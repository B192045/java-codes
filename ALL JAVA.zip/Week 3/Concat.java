import java.util.*;

public class Concat{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   String A=sc.nextLine();
   String B=sc.nextLine();
   System.out.println(A.concat(B));
   }}