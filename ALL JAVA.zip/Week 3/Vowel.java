import java.util.*;

public class Vowel{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   ArrayList<Character> vowel=new ArrayList<>();
   ArrayList<Character> consonant=new ArrayList<>();  
   int i;
   String A=sc.nextLine();
   char[] ch=A.toCharArray();
   for(i=0;i<A.length();i++){
    if(ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||ch[i]=='U')
    vowel.add(ch[i]);
    else
    consonant.add(ch[i]);
    }
    System.out.println("vowels are: "+vowel);
    System.out.println("vowel count is: "+vowel.size());
    System.out.println("consonants are: "+consonant);
    System.out.println("consonant count is: "+consonant.size());
}}

