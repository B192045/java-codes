import java.util.*;

public class IndexOf{
 public static void main(String args[]){
   Scanner sc=new Scanner(System.in);
   ArrayList<Integer> list=new ArrayList<>();
   int c=0,i,index,index2;
   String A=sc.nextLine();
   char[] ch=A.toCharArray();
  for(i=0;i<A.length();i++){
  index = A.indexOf(ch[i]);
   list.add(index);}
   System.out.println(list);
   System.out.println("Enter the character to find num of occurences: ");
   String s=sc.next();
   index2=A.indexOf(s);
   for(i=0;i<list.size();i++){
   if(list.get(i)==index2)
   c++;}
  System.out.println("frequency is "+c);
   }}