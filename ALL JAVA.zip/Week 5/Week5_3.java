/* Create an interface Vehicle with methods getCompany(),getModel(),getType() (Petrol/Diesel/CNG) and getConsumption(), display Company and Model, type and calculate the fuel consumed by Two wheelers and Four Wheelers by implementing interface Vehicle.*/

import java.util.*;

interface Vehicle{
 String getCompany();
  String getModel();
 String getType();
  int getConsumption();
   }
 
 class Twowheelers implements Vehicle{
 String company;
String model;
  String type;
   int distance;
 int consumption;
  
  Twowheelers(String company,String model,String type,int distance){
  this.company=company;
  this.model=model;
  this.type=type;
  this.distance=distance;
  }
  
  public String getCompany(){
  return company;}
  public String getModel(){
  return model;}
  public String getType(){
  return type;}
  public int getConsumption(){
  if (type.equalsIgnoreCase("Petrol")) {
this.consumption =distance/62;}
else if (type.equalsIgnoreCase("Diesel")) {
this.consumption = distance/82;}
else if(type.equalsIgnoreCase("CNG")) {
this.consumption = distance/72;}
return consumption;}
}

class Fourwheelers implements Vehicle{
 String company;
String model;
  String type;
   int distance;
 int consumption;
  
  Fourwheelers(String company,String model,String type,int distance){
  this.company=company;
  this.model=model;
  this.type=type;
  this.distance=distance;
  }
  
  public String getCompany(){
  return company;}
  public String getModel(){
  return model;}
  public String getType(){
  return type;}
  public int getConsumption(){
  if (type.equalsIgnoreCase("Petrol")) {
this.consumption =distance/14;}
else if (type.equalsIgnoreCase("Diesel")) {
this.consumption = distance/22;}
else if(type.equalsIgnoreCase("CNG")) {
this.consumption = distance/18;}
return consumption;}
}

class Week5_3{
 public static void main(String args[]){
  Twowheelers t1=new Twowheelers("Maruti","herohonda","petrol",14);
  System.out.println(t1.getCompany()+" "+t1.getModel()+" "+t1.getType()+" "+t1.getConsumption());
  Fourwheelers t2=new Fourwheelers("Maruti","Alto","petrol",14);
  System.out.println(t2.getCompany()+" "+t2.getModel()+" "+t2.getType()+" "+t2.getConsumption());}}
  
  
