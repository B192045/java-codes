/* 4. Create an Interface Fare with methods getFare(), getAmenities() to get the
amount paid for Travelling and Amenities provided in journey. Calculate the fare
paid and Amenities provided in Bus, Train and Flight implementing interface Fare.
Note :The Fare per Kilometer is different for Road and Rail and airways and even
the fare changes as per type of Bus (A/c, Non A/c, sleeper, semi sleeper etc.,)
Train( General, Sleeper, A/c), Flight (Economy/Business class) . Make necessary
assumptions on distance travelled etc.,.*/

import java.util.*;

interface Fare{
 int getfare();
 int getamenities();}
 
 class Bus implements Fare{
   String type;
   int distance;
   
   Bus(String type,int distance){
   this.type=type;
   this.distance=distance;}
   
   int getfare(){
   if(type.equalsIgnoreCase("AC"))
   int rate=2000;
   if(type.equalsIgnoreCase("Non AC")
   


