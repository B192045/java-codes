import java.util.*;

public class Person{
 String name;
 String address;

 Person{
 this.name=name;
 this.address=address;}

void getname(){
return name;}

void getaddress(){
return address;}
}

public class Student{
 final int MAX_COURSES=30;
 int numcourse=0;
 String courses[]=new String[30];
 String grade[]=new int[30];

 Student(String name,String address){
 super(name,address);}

void coursewithgrade(){
 if(numcourses<MAX_COURSES){
 courses[numcourses]=course;
 grades[numcourses]=grade;
 numcourses++;}
 else
 System.out.println("exceeded");}

void printcourse(){
int i;
for(i=0;i<numcourses;i++)
System.out.println(courses[i]);}

double getavg(){
 if(numcourses=0);
 return 0;
 int sum=0;
 for(i=0;i<numcourses;i++)
 sum=sum+i
return (double)sum/numcourses;}}

public class Teacher extends Person{
 final max=5;
 String coursestaught[]=new String[5];
 int numofcourses=0;

 Teacher(String name,String address){
 super(name,address);}

 void addcourse(String course){
  if(numofcourses<max){
  for(i=0;i<numofcourses;i++){
  coursestaught[i]=course;
 numofcourses++;}
else
System.out.println("exceeded");}


 


