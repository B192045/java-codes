import java.util.ArrayList;
import java.util.Scanner;

class Vehicle {
    String company;
    String model;
    double mileage;
    double fuelCapacity;
    double displacement;

    // Common properties and methods for all vehicles

    public Vehicle(String company, String model, double mileage, double fuelCapacity, double displacement) {
        this.company = company;
        this.model = model;
        this.mileage = mileage;
        this.fuelCapacity = fuelCapacity;
        this.displacement = displacement;
    }

    public void displayDetails() {
        System.out.println("Company: " + company);
        System.out.println("Model: " + model);
        System.out.println("Mileage: " + mileage);
        System.out.println("Fuel Capacity: " + fuelCapacity);
        System.out.println("Displacement: " + displacement);
    }
}

class TwoWheeler extends Vehicle {
    String frontBrake;
    String rearBrake;
    String tyreType;
    String headLamp;
    String userReviews;

    public TwoWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
                      String frontBrake, String rearBrake, String tyreType, String headLamp, String userReviews) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.frontBrake = frontBrake;
        this.rearBrake = rearBrake;
        this.tyreType = tyreType;
        this.headLamp = headLamp;
        this.userReviews = userReviews;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Front Brake: " + frontBrake);
        System.out.println("Rear Brake: " + rearBrake);
        System.out.println("Tyre Type: " + tyreType);
        System.out.println("Head Lamp: " + headLamp);
        System.out.println("User Reviews: " + userReviews);
    }
}

class FourWheeler extends Vehicle {
    boolean airConditioner;
    boolean airBags;
    boolean powerSteering;
    boolean rainSensingWiper;

    public FourWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
                       boolean airConditioner, boolean airBags, boolean powerSteering, boolean rainSensingWiper) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.airConditioner = airConditioner;
        this.airBags = airBags;
        this.powerSteering = powerSteering;
        this.rainSensingWiper = rainSensingWiper;
    }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Air Conditioner: " + airConditioner);
        System.out.println("Air Bags: " + airBags);
        System.out.println("Power Steering: " + powerSteering);
        System.out.println("Rain Sensing Wiper: " + rainSensingWiper);
    }
}

public class VehicleComparisonApp {
    public static void main(String[] args) {
        ArrayList<TwoWheeler> twoWheelers = new ArrayList<>();
        twoWheelers.add(new TwoWheeler("Honda", "Activa", 45.0, 5.3, 110.0, "Drum", "Drum", "Tubeless", "Halogen", "Positive"));
        twoWheelers.add(new TwoWheeler("Suzuki", "Access", 50.0, 5.0, 125.0, "Disc", "Drum", "Tubeless", "LED", "Positive"));
        twoWheelers.add(new TwoWheeler("Yamaha", "FZ", 40.0, 13.0, 149.0, "Disc", "Disc", "Tubeless", "LED", "Positive"));
        twoWheelers.add(new TwoWheeler("TVS", "Apache", 35.0, 12.0, 160.0, "Disc", "Disc", "Tubeless", "LED", "Positive"));

        ArrayList<FourWheeler> fourWheelers = new ArrayList<>();
        fourWheelers.add(new FourWheeler("Toyota", "Camry", 20.0, 50.0, 2500.0, true, true, true, true));
        fourWheelers.add(new FourWheeler("Honda", "City", 18.0, 45.0, 1500.0, true, true, true, true));
        fourWheelers.add(new FourWheeler("Maruti", "Swift", 22.0, 42.0, 1200.0, false, true, true, false));
        fourWheelers.add(new FourWheeler("Ford", "Endeavour", 12.0, 80.0, 3000.0, true, true, true, true));

        Scanner scanner = new Scanner(System.in);

        System.out.println("Available Vehicles:");
        System.out.println("1. Two-Wheelers");
        for (TwoWheeler twoWheeler : twoWheelers) {
            System.out.println(twoWheeler.company + " " + twoWheeler.model);
        }

        System.out.println("2. Four-Wheelers");
        for (FourWheeler fourWheeler : fourWheelers) {
            System.out.println(fourWheeler.company + " " + fourWheeler.model);
        }

        System.out.println("Enter the number of vehicles to compare:");
        int numToCompare = scanner.nextInt();

        ArrayList<Vehicle> selectedVehicles = new ArrayList<>();
        for (int i = 0; i < numToCompare; i++) {
            System.out.println("Enter the vehicle type (1 for Two-Wheeler, 2 for Four-Wheeler):");
            int vehicleType = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            if (vehicleType == 1) {
                System.out.println("Enter the Two-Wheeler company and model:");
                String twoWheelerDetails = scanner.nextLine();
                TwoWheeler selectedTwoWheeler = findTwoWheeler(twoWheelers, twoWheelerDetails);
                if (selectedTwoWheeler != null) {
                    selectedVehicles.add(selectedTwoWheeler);
                } else {
                    System.out.println("Invalid Two-Wheeler details. Try again.");
                    i--;  // Decrement the loop counter to re-enter the details
                }
            } else if (vehicleType == 2) {
                System.out.println("Enter the Four-Wheeler company and model:");
                String fourWheelerDetails = scanner.nextLine();
                FourWheeler selectedFourWheeler = findFourWheeler(fourWheelers, fourWheelerDetails);
                if (selectedFourWheeler != null) {
                    selectedVehicles.add(selectedFourWheeler);
                } else {
                    System.out.println("Invalid Four-Wheeler details. Try again.");
                    i--;  // Decrement the loop counter to re-enter the details
                }
            } else {
                System.out.println("Invalid choice. Try again.");
                i--;  // Decrement the loop counter to re-enter the details
            }
        }

        // Compare and display the selected vehicles
        System.out.println("Comparison Result:");
        for (Vehicle vehicle : selectedVehicles) {
            System.out.println("----------------------------");
            vehicle.displayDetails();
            System.out.println("----------------------------");
        }
    }

    private static TwoWheeler findTwoWheeler(ArrayList<TwoWheeler> twoWheelers, String details) {
        for (TwoWheeler twoWheeler : twoWheelers) {
            if ((twoWheeler.company + " " + twoWheeler.model).equalsIgnoreCase(details)) {
                return twoWheeler;
            }
        }
        return null;
    }

    private static FourWheeler findFourWheeler(ArrayList<FourWheeler> fourWheelers, String details) {
        for (FourWheeler fourWheeler : fourWheelers) {
            if ((fourWheeler.company + " " + fourWheeler.model).equalsIgnoreCase(details)) {
                return fourWheeler;
            }
        }
        return null;
    }
}
