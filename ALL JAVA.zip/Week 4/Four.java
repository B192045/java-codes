import java.util.*;

public class Vehicle{
 String company;
 String model;
 int mileage;
 int fuelcapacity;
 int displacement;

 Vehicle(String company,String model,int mileage,int fuelcapacity,int displacement){
    this.company=company;
    this.model=model;
    this.mileage=mileage;
    this.fuelcapacity=fuelcapacity;
    this.dispacement=displacement;}} 

class Twowheeler extends Vehicle{
 String front_brake;
 String rear_brake;
 String tyre_type;
 String head_lamp;
 String userreviews;
 
 Twowheeler(String company,String model,int mileage,int fuelcapacity,int displacement,String front_brake,String rear_brake,String tyre_type,String head_lamp,String  userreviews){
 super(company,model,mileage,fuelcapacity,displacement);
 this.front_brake=front_brake;
 this.rear_brake=rear_brake;
this.tyre_type=tyre_type;
this.head_lamp=head_lamp;
this.userreviews=userreviews;}}

class Fourwheeler extends Vehicle{
 boolean ac;
 boolean steering;
 boolean wiper;
 boolean airbags;

Fourwheeler(String company,String model,int mileage,int fuelcapacity,int displacement,boolean ac,boolean steering,boolean wiper,boolean airbags){
 this.ac=ac;
 this.steering=steering;
 this.wiper=wiper;
 this.airbags=airbags;}}



 




