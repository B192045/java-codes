import java.util.*;

class Person{
  String name;
  String address;
  public Person(String name,String address){
   this.name=name;
   this.address=address;
   }
  String getName(){
  return name;}
  
  String getaddress(){
  return address;}
  
 class Student extends Person{
 HashMap<String,Integer> h1=new HashMap<>();
  final int max=30;
  int numcourses=0;
  String courses;
  int grades;
  
  Student(String name,String address){
  super(name,address);}
  
  void addcourse(String course,int grade){
    if(numcourses<max){
     h1.put(course,grade);
     numcourses++;}
     else
     System.out.println("exceeded");}
     
    void print(){
    System.out.println(h1);
  
 }}
  
 

public static void main(String[] args) {
Student s1= new Student("John Doe", "123 Main St");
s1.addcourse("Math", 25);
s1.addcourse("Science", 25);
s1.print();
}}
