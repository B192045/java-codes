import java.util.*;

class Company{
 String productname;
 String company;
 int quantity;

Company(String productname,String company,int quantity){
 this.productname=productname;
 this.company=company;
 this.quantity=quantity;}

public int cost(){
return 0;
}}

class Amazon extends Company{
 boolean ishdfcholder;
 int price;
 int costs=0;
Amazon(String productname,String company,int quantity,boolean ishdfcholder,int price){
 super(productname,company,quantity);
 this.ishdfcholder=ishdfcholder;
this.price=price;}

public int cost(){
 if(ishdfcholder){
 costs=(int)(price+price*0.1);}
 if(price>50000)
 costs=(int)(price+price*0.15);
 return costs;}}

class Flipkart extends Company{
 boolean rgukt;
 int price;
 int costs=0;
Flipkart(String productname,String company,int quantity,boolean rgukt,int price){
 super(productname,company,quantity);
 this.rgukt=rgukt;
this.price=price;}

public int cost1(){
 if(rgukt){
 costs=(int)(price+price*0.03);}
 if(price>30000)
 costs=(int)(price+price*0.05);
 return costs;}}


public class Compan{
public static void main(String args[]){
 Amazon c1 = new Amazon("car", "alto", 2, true, 5000);
        System.out.println(c1.cost());
Flipkart c2 = new Flipkart("car", "alto", 2, true, 5000);
System.out.println(c2.cost1());
if(c1.cost()>c2.cost1())
System.out.println("flipkart");
else
System.out.println("Amazon");
}}

 
 