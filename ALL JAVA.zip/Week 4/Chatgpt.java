import java.util.ArrayList;
import java.util.Scanner;

class Vehicle {
    String company;
    String model;
    double mileage;
    double fuelCapacity;
    double displacement;

    public Vehicle(String company, String model, double mileage, double fuelCapacity, double displacement) {
        this.company = company;
        this.model = model;
        this.mileage = mileage;
        this.fuelCapacity = fuelCapacity;
        this.displacement = displacement;
    }

    public void displayDetails() {
        System.out.println("Company: " + company);
        System.out.println("Model: " + model);
        System.out.println("Mileage: " + mileage + " km/l");
        System.out.println("Fuel Capacity: " + fuelCapacity + " liters");
        System.out.println("Displacement: " + displacement + " cc");
    }
}

class TwoWheeler extends Vehicle {
    String frontBrake;
    String rearBrake;
    String tyreType;
    String headLamp;
    String userReviews;

    public TwoWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
                      String frontBrake, String rearBrake, String tyreType, String headLamp, String userReviews) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.frontBrake = frontBrake;
        this.rearBrake = rearBrake;
        this.tyreType = tyreType;
        this.headLamp = headLamp;
        this.userReviews = userReviews;
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Front Brake: " + frontBrake);
        System.out.println("Rear Brake: " + rearBrake);
        System.out.println("Tyre Type: " + tyreType);
        System.out.println("Head Lamp: " + headLamp);
        System.out.println("User Reviews: " + userReviews);
    }
}

class FourWheeler extends Vehicle {
    boolean airConditioner;
    int airBags;
    boolean powerSteering;
    boolean rainSensingWiper;

    public FourWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
                       boolean airConditioner, int airBags, boolean powerSteering, boolean rainSensingWiper) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.airConditioner = airConditioner;
        this.airBags = airBags;
        this.powerSteering = powerSteering;
        this.rainSensingWiper = rainSensingWiper;
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Air Conditioner: " + (airConditioner ? "Yes" : "No"));
        System.out.println("Air Bags: " + airBags);
        System.out.println("Power Steering: " + (powerSteering ? "Yes" : "No"));
        System.out.println("Rain Sensing Wiper: " + (rainSensingWiper ? "Yes" : "No"));
    }
}

public class Chatgpt {
    public static void main(String[] args) {
        // Create and store vehicle details in a repository
        ArrayList<Vehicle> repository = new ArrayList<>();
        repository.add(new TwoWheeler("Honda", "CBR 150R", 40.5, 10, 150, "Disc", "Drum", "Tubeless", "LED", "Excellent"));
        repository.add(new TwoWheeler("Yamaha", "FZ-S", 45.2, 12, 160, "Disc", "Disc", "Tubeless", "Halogen", "Good"));
        repository.add(new FourWheeler("Toyota", "Camry", 18.5, 55, 2500, true, 6, true, true));
        repository.add(new FourWheeler("Honda", "Civic", 16.8, 50, 1800, true, 4, true, false));

        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose the type of vehicle (2 for Two Wheeler, 4 for Four Wheeler):");
        int vehicleType = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Available vehicles:");
        int vehicleCount = 0;
        for (int i = 0; i < repository.size(); i++) {
            if ((vehicleType == 2 && repository.get(i) instanceof TwoWheeler) ||
                    (vehicleType == 4 && repository.get(i) instanceof FourWheeler)) {
                System.out.println(++vehicleCount + ". " + repository.get(i).company + " " + repository.get(i).model);
            }
        }

        System.out.println("Choose the vehicles you want to compare (e.g., 1 2):");
        String input = scanner.nextLine();
        String[] choices = input.split(" ");
        System.out.println("You have chosen the following vehicles to compare:");
       scanner.nextLine();
        for (String choice : choices) {
            int index = Integer.parseInt(choice) - 1;
            if (index >= 0 && index < repository.size() && ((vehicleType == 2 && repository.get(index) instanceof TwoWheeler) ||
                    (vehicleType == 4 && repository.get(index) instanceof FourWheeler))) {
                repository.get(index).displayDetails();
            }
        }
    }
}
